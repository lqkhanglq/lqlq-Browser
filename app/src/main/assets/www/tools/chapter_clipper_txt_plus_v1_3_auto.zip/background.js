const STORAGE_KEY = "chapterClipperTxtStateV2";

const DEFAULT_STATE = {
  popupBlocker: true
};

function getState() {
  return new Promise((resolve) => {
    chrome.storage.local.get([STORAGE_KEY], (data) => {
      resolve(Object.assign({}, DEFAULT_STATE, data[STORAGE_KEY] || {}));
    });
  });
}

function isMetruyenUrl(url) {
  try {
    const u = new URL(url || "");
    return /(^|\.)metruyenchuvn\.com$/i.test(u.hostname);
  } catch {
    return false;
  }
}

function isSuspiciousPopupUrl(url) {
  if (!url) return true;
  try {
    const u = new URL(url);
    if (isMetruyenUrl(url)) return false;

    const h = u.hostname.toLowerCase();
    const s = url.toLowerCase();

    const badHost = [
      "doubleclick.net",
      "googlesyndication.com",
      "googleadservices.com",
      "popads.net",
      "popcash.net",
      "adnxs.com"
    ];

    if (badHost.some(x => h === x || h.endsWith("." + x))) return true;

    return /(ads?|advert|banner|promo|click|track|pop|redirect|campaign|aff|offer)/i.test(s);
  } catch {
    return true;
  }
}

async function closeIfPopupAd(tab) {
  const state = await getState();
  if (!state.popupBlocker) return;
  if (!tab || tab.openerTabId == null) return;

  let opener;
  try {
    opener = await chrome.tabs.get(tab.openerTabId);
  } catch {
    return;
  }

  if (!opener || !isMetruyenUrl(opener.url)) return;

  const url = tab.url || tab.pendingUrl || "";
  if (!isSuspiciousPopupUrl(url)) return;

  try {
    await chrome.tabs.remove(tab.id);
    await chrome.tabs.update(opener.id, { active: true });
    if (opener.windowId != null) await chrome.windows.update(opener.windowId, { focused: true });
  } catch {}
}

chrome.tabs.onCreated.addListener((tab) => {
  setTimeout(() => closeIfPopupAd(tab), 50);
  setTimeout(async () => {
    try {
      const t = await chrome.tabs.get(tab.id);
      closeIfPopupAd(t);
    } catch {}
  }, 500);
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url || changeInfo.status === "loading") closeIfPopupAd(tab);
});