# Chapter Clipper TXT Plus v1.2

Bản này sửa lỗi lấy thiếu nội dung chương.

Điểm mới:
- Đổi thuật toán lấy chương:
  - Không chỉ chọn một khối `.container` theo điểm nữa.
  - Ưu tiên lấy theo ranh giới toàn trang: sau tiêu đề chương -> đến nút cuối chương.
  - Giảm lỗi cắt thiếu phần đầu/cuối chương.
- Thêm nút **Kiểm tra lấy nội dung**:
  - Hiện số ký tự lấy được.
  - Hiện đoạn đầu và đoạn cuối để bạn kiểm tra nhanh trước khi lưu.
- Tự bỏ dòng thừa kiểu:
  - 《 Chương trước
  - Chương tiếp 》
  - Tải Ebook
  - Báo lỗi
  - Bình luận

## Cài đặt

Nên gỡ bản cũ trước:
1. Vào `chrome://extensions`
2. Xóa extension cũ `Chapter Clipper TXT Plus` hoặc `Chapter Clipper TXT`

Cài bản mới:
1. Giải nén zip này.
2. Vào `chrome://extensions`
3. Bật Developer mode.
4. Bấm Load unpacked.
5. Chọn thư mục có file `manifest.json`.

## Cách dùng

1. Mở chương truyện.
2. Bấm **Kiểm tra lấy nội dung** trước.
3. Nếu số ký tự hợp lý và đoạn cuối đúng cuối chương, bấm:
   - **Lưu chương FULL**, hoặc
   - **Lưu FULL & chương tiếp**
4. Đủ số chương trong ô `Tự xuất mỗi ... chương`, extension tự tải TXT.

## Phím tắt

- Ctrl+Shift+S: Lưu chương FULL
- Ctrl+Shift+N: Lưu FULL & chương tiếp
- Ctrl+Shift+E: Xuất TXT ngay

====================================================
# V1.3 - CHẾ ĐỘ TỰ ĐỘNG (mới)

Bấm 1 nút, extension tự lặp: Lưu FULL -> Chương tiếp -> Lưu FULL -> ...
cho đến khi đủ số chương bạn nhập.

## Cách dùng
1. Mở chương muốn bắt đầu lưu.
2. Nhập số chương vào ô "Tự động ... chương" (ví dụ 10, 100, 500...).
3. Bấm "▶ Bắt đầu tự động" (hoặc Ctrl+Shift+A).
4. Ngồi chờ. Mỗi khi đủ số trong ô "Tự xuất mỗi ... chương" nó vẫn
   tự tải file TXT như cũ.
5. Muốn dừng giữa chừng: bấm "⏹ Dừng" (hoặc Ctrl+Shift+A lần nữa).

## Lưu ý
- Trong lúc chạy, ĐỪNG bấm lung tung trên tab đó (chuyển trang tay,
  đóng tab...). Có thể mở tab khác làm việc bình thường.
- Giữa các chương có nghỉ ngẫu nhiên 1-2.5 giây cho giống người đọc,
  tránh bị web chặn.
- Tự dừng khi: hết số chương đã đặt, hết truyện (không còn nút
  Chương tiếp), hoặc trang không tải được nội dung sau 25 giây.
- Khi dừng/xong, nếu còn chương lẻ chưa đủ lô, nó tự xuất nốt file TXT
  phần còn lại (nếu đang bật "Đủ số thì tự tải TXT").
- Nếu lỡ F5 giữa chừng: không sao, nó tự chạy tiếp, không lưu trùng.

## Phím tắt mới
- Ctrl+Shift+A: Bắt đầu / Dừng tự động
